export { default } from './src/loadmore.vue';
