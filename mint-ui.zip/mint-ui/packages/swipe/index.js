export { default } from './src/swipe.vue';
