export { default } from './src/tab-container.vue';
